<header id="header">
    <div class="wpo-site-header <?php echo $HeaderStyle; ?>">
        <nav class="navigation navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <div class="row align-items-center g-0">
                    <div class="col-lg-3 col-md-3 col-3 d-lg-none dl-block">
                        <div class="mobail-menu">
                            <button type="button" class="navbar-toggler open-btn">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar first-angle"></span>
                                <span class="icon-bar middle-angle"></span>
                                <span class="icon-bar last-angle"></span>
                            </button>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="index.php"><img src="assets/images/header-logo.png"
                                    alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-1 col-1">
                        <div id="navbar" class="collapse navbar-collapse navigation-holder">
                            <button class="menu-close"><i class="ti-close"></i></button>
                            <ul class="nav navbar-nav mb-2 mb-lg-0">
                                <li class="menu-item-has-children image-style-item">
                                    <a href="#">Home</a>
                                    <ul class="sub-menu image-style">
                                        <li>
                                            <a href="index.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/modern-architecture.jpg"
                                                        alt="">
                                                </small>
                                                <span>Modern Architecture</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-classic-architecture.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/classic-architecture.jpg"
                                                        alt="">
                                                </small>
                                                <span>Classic Architecture</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-modern-architecture-s2.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/modern-architecture-s2.jpg"
                                                        alt="">
                                                </small>
                                                <span>Modern Architecture 02</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-classic-architecture-dark.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/classic-architecture-dark.jpg"
                                                        alt="">
                                                </small>
                                                <span>Classic Architecture Dark</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-classic-interior-design.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/classic-interior-design.jpg"
                                                        alt="">
                                                </small>
                                                <span>Classic Interior Design</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-classic-interior-design-s2.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/classic-interior-design-s2.jpg"
                                                        alt="">
                                                </small>
                                                <span>Classic Interior Design 02</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-classic-interior-design-dark.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/classic-interior-design-dark.jpg"
                                                        alt="">
                                                </small>
                                                <span>Classic Interior Design Dark</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-renovation.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/renovation.jpg" alt="">
                                                </small>
                                                <span>Renovation</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-modern-woocommerce.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/modern-woocommerce.jpg" alt="">
                                                </small>
                                                <span>Modern Woocommerce</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-minimal-woocommerce.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/minimal-woocommerce-s2.jpg"
                                                        alt="">
                                                </small>
                                                <span>Minimal Woocommerce</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-urban-planning.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/urban-planning.jpg" alt="">
                                                </small>
                                                <span>Urban Planning</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-costruction.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/costruction.jpg" alt="">
                                                </small>
                                                <span>Costruction</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-costruction-s2.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/costruction-s2.jpg" alt="">
                                                </small>
                                                <span>Costruction 02</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-costruction-profile.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/construction-profile.jpg"
                                                        alt="">
                                                </small>
                                                <span>Costruction Profile</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="bliize-frelancer-architect.php">
                                                <small class="inner">
                                                    <img src="assets/images/home/frelancer-architect.jpg"
                                                        alt="">
                                                </small>
                                                <span>Frelancer Architect</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Pages</a>
                                    <ul class="sub-menu">
                                        <li><a href="about.php">About Us</a></li>
                                        <li class="menu-item-has-children">
                                            <a href="#">Services</a>
                                            <ul class="sub-menu">
                                                <li><a href="services.php">Services</a></li>
                                                <li><a href="service-single.php">Service single</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="#">Team</a>
                                            <ul class="sub-menu">
                                                <li><a href="team.php">Team</a></li>
                                                <li><a href="team-single.php">Team single</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="pricing.php">Pricing</a></li>
                                        <li><a href="login.php">Login</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                        <li><a href="privacy.php">privacy</a></li>
                                        <li><a href="terms.php">Terms</a></li>
                                        <li><a href="404.php">404 Error</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Projects</a>
                                    <ul class="sub-menu">
                                        <li><a href="projects.php">Projects</a></li>
                                        <li><a href="project-single.php">Projects Single</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Shop</a>
                                    <ul class="sub-menu">
                                        <li><a href="shop.php">Shop</a></li>
                                        <li><a href="shop-single.php">Shop Single</a></li>
                                        <li><a href="cart.php">Cart</a></li>
                                        <li><a href="checkout.php">Checkout</a></li>
                                        <li><a href="wishlist.php">Wishlist</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Blog</a>
                                    <ul class="sub-menu">
                                        <li><a href="blog.php">Blog right sidebar</a></li>
                                        <li><a href="blog-left-sidebar.php">Blog left sidebar</a></li>
                                        <li><a href="blog-fullwidth.php">Blog fullwidth</a></li>
                                        <li class="menu-item-has-children">
                                            <a href="#">Blog details</a>
                                            <ul class="sub-menu">
                                                <li><a href="blog-single.php">Blog details right sidebar</a>
                                                </li>
                                                <li><a href="blog-single-left-sidebar.php">Blog details left
                                                        sidebar</a></li>
                                                <li><a href="blog-single-fullwidth.php">Blog details
                                                        fullwidth</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-2 col-2">
                        <div class="header-right">
                            <div class="header-search-form-wrapper">
                                <div class="cart-search-contact">
                                    <button class="search-toggle-btn"><i class="fi flaticon-loupe"></i></button>
                                    <div class="header-search-form">
                                        <form>
                                            <div>
                                                <input type="text" class="form-control"
                                                    placeholder="Search here...">
                                                <button type="submit"><i class="fi flaticon-loupe"></i></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="close-form">
                                <a class="theme-btn" href="contact.php">Contact Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</header>
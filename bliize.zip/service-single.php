<!DOCTYPE html>
<html lang="en">
<?php include './partials/head.php' ?>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <?php include './partials/preloader.php' ?>
        <!-- end preloader -->

        <!--  cursor style -->
        <div class="cursor"></div>
        <div class="cursor2"></div>

        <!-- Start header -->
        <header id="header">
            <?php
            $HeaderStyle = 'wpo-header-style-s11';
            ?>
            <?php include './partials/header-topbar-s2.php' ?>
            <?php include './partials/header-six.php' ?>
        </header>
        <!-- end of header -->

        <!-- start wpo-page-title -->
        <?php
        $Title = 'Service Single';
        $MainTitle = 'Design & Planning';
        ?>
        <?php include './partials/page-header.php' ?>
        <!-- end page-title -->

        <!--===== start service-single-page =====-->
        <section class="service-single-page">
            <div class="container-fluid">
                <div class="service-image scroll-text-animation" data-animation="fade_from_bottom">
                    <img src="assets/images/service-single/single.jpg" alt="">
                </div>
                <div class="row align-items-center">
                    <div class="col-lg-8  col-12">
                        <div class="content">
                            <h2 class="poort-text poort-in-right">What’s part of the service</h2>
                            <p><span>M</span>odern Buildings Ipsum is simply dummy text of the printing and typesetting
                                industry. Lorem Ipsum has beening the industry's standard dummy text ever since the
                                1500s, when an unknown printer took a galley of type and scrambled it to make a good
                                type specimen book. It has survived not only five centuries, but also the leap into
                                electronic typesetting, remaining essentially unchanged. It was a popularised in the
                                1960s with the release of Letraset sheets containing Lorem Ipsum passages.</p>
                            <p>Lorem ipsum dolor sit amet consectetur. Sit aliquam dignissim situt id amet cyrium. Nulla
                                thurg varius purus bibendum pellentesque eu sit nascetur vitae. Nibh tortor etrutnibh
                                tincidunt tempor proin. Est placerat felis pellentesque temupus condimentum consectetur.
                                Faucibus nunc pellentesque ac mus posuere aliquam mor augue orci. Egestas donec sit
                                pellentesque lacus.</p>
                        </div>
                    </div>
                    <div class="col-lg-4  col-12 scroll-text-animation" data-animation="fade_from_bottom">
                        <div class="video" style="background: url(assets/images/wpo-video.jpg);">
                            <div class="video-holder">
                                <a href="https://www.youtube.com/embed/uySn1BZiWWs?si=XcM3FYqzlXkJaB0v"
                                    class="video-btn" data-type="iframe">
                                    <svg width="100" height="100" viewBox="0 0 100 100" fill="none">
                                        <circle cx="50" cy="50" r="50" fill="white" />
                                        <path
                                            d="M65.5 47.4019C67.5 48.5566 67.5 51.4434 65.5 52.5981L44.5 64.7224C42.5 65.8771 40 64.4338 40 62.1244L40 37.8756C40 35.5662 42.5 34.1229 44.5 35.2776L65.5 47.4019Z"
                                            fill="black" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- dream-section -->
        <section class="dream-section">
            <div class="container-fluid">
                <div class="dream-wrap">
                    <div class="title">
                        <h2>Making Your Dream True!</h2>
                        <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                            of type and scrambled.Lorem ipsum dolor sit amet consectetur. Sit aliquam dignissim situt id
                            amet cyrium. Nulla thurg varius purus bibendum pellentesque eu sit nascetur vitae. Nibh
                            tortor etrutnibh tincidunt tempor proin. Est placerat felis pellentesque temupus condimentum
                            consectetur. Faucibus nunc pellentesque ac mus posuere aliquam mor augue orci. Egestas donec
                            sit pellentesque lacus.</p>
                    </div>
                    <div class="image-wrap">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-12 scroll-text-animation"
                                data-animation="fade_from_bottom">
                                <div class="image">
                                    <img src="assets/images/service-single/dream/1.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-12 scroll-text-animation"
                                data-animation="fade_from_bottom">
                                <div class="image">
                                    <img src="assets/images/service-single/dream/2.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--  service-business -->
        <section class="service-business section-padding">
            <div class="container-fluid">
                <div class="project-title">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-12">
                            <h2 class="poort-text poort-in-right">Your Dream Our Endless Passion</h2>
                        </div>
                        <div class="col-lg-6 col-12">
                            <p class="poort-text poort-in-right">Simply dummy text of the printing and typesetting
                                industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                                when an unknown printer took a galley of type and scrambled.</p>
                        </div>
                    </div>
                </div>
                <div class="image-wrap">
                    <div class="row">
                        <div class="col col-lg-6 col-md-12 col-12 scroll-text-animation"
                            data-animation="fade_from_bottom">
                            <div class="image">
                                <img src="assets/images/service-single/dream/3.jpg" alt="">
                            </div>
                        </div>
                        <div class="col col-lg-6 col-md-12 col-12 scroll-text-animation"
                            data-animation="fade_from_bottom">
                            <div class="image">
                                <img src="assets/images/service-single/dream/4.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--===== start wpo-testimonial-section =====-->
        <section class="wpo-testimonial-section-s3 section-padding">
            <div class="testimonial-slider-s3 owl-carousel">
                <div class="item">
                    <div class="content">
                        <div class="icon">
                            <img src="assets/images/testimonial/quote-2.svg" alt="quote">
                        </div>
                        <h3>“Bliize next level flexitarian yr bicycle rights waistcoat bit austin tofu-daa glossier
                            whatever scenester snack wave literally can shaman grained.”</h3>
                        <div class="client-wrap">
                            <div class="image">
                                <img src="assets/images/testimonial/client/1.jpg" alt="">
                            </div>
                            <div class="text">
                                <h4>Leslie Alexander</h4>
                                <span>Marketing Coordinator</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="content">
                        <div class="icon">
                            <img src="assets/images/testimonial/quote-2.svg" alt="quote">
                        </div>
                        <h3>“Bliize next level flexitarian yr bicycle rights waistcoat bit austin tofu-daa glossier
                            whatever scenester snack wave literally can shaman grained.”</h3>
                        <div class="client-wrap">
                            <div class="image">
                                <img src="assets/images/testimonial/client/2.jpg" alt="">
                            </div>
                            <div class="text">
                                <h4>John Abraham</h4>
                                <span>WEb Developer</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="content">
                        <div class="icon">
                            <img src="assets/images/testimonial/quote-2.svg" alt="quote">
                        </div>
                        <h3>“Bliize next level flexitarian yr bicycle rights waistcoat bit austin tofu-daa glossier
                            whatever scenester snack wave literally can shaman grained.”</h3>
                        <div class="client-wrap">
                            <div class="image">
                                <img src="assets/images/testimonial/client/1.jpg" alt="">
                            </div>
                            <div class="text">
                                <h4>Leslie Alexander</h4>
                                <span>Marketing Coordinator</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="content">
                        <div class="icon">
                            <img src="assets/images/testimonial/quote-2.svg" alt="quote">
                        </div>
                        <h3>“Bliize next level flexitarian yr bicycle rights waistcoat bit austin tofu-daa glossier
                            whatever scenester snack wave literally can shaman grained.”</h3>
                        <div class="client-wrap">
                            <div class="image">
                                <img src="assets/images/testimonial/client/2.jpg" alt="">
                            </div>
                            <div class="text">
                                <h4>John Abraham</h4>
                                <span>WEb Developer</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--===== start wpo-partners-section =====-->
        <section class="wpo-partners-section bb-0 fade_bottom">
            <h2 class="d-none">No Content</h2>
            <ul class="partners-slider">
                <li>
                    <div>
                        <img src="assets/images/partners/1.png" alt="">
                    </div>
                </li>
                <li>
                    <div>
                        <img src="assets/images/partners/2.png" alt="">
                    </div>
                </li>
                <li>
                    <div>
                        <img src="assets/images/partners/3.png" alt="">
                    </div>
                </li>
                <li>
                    <div>
                        <img src="assets/images/partners/4.png" alt="">
                    </div>
                </li>
                <li>
                    <div>
                        <img src="assets/images/partners/5.png" alt="">
                    </div>
                </li>
                <li>
                    <div>
                        <img src="assets/images/partners/2.png" alt="">
                    </div>
                </li>
            </ul>
        </section>


        <!-- start wpo-site-footer -->
        <?php include './partials/footer.php' ?>
        <!-- end wpo-site-footer -->

    </div>
    <!-- end of page-wrapper -->
    <?php include './partials/script.php' ?>
</body>

</html>
<!DOCTYPE html>
<html lang="en">
<?php include './partials/head.php' ?>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <?php include './partials/preloader.php' ?>
        <!-- end preloader -->

        <!--  cursor style -->
        <div class="cursor"></div>
        <div class="cursor2"></div>

        <!-- Start header -->
        <header id="header">
            <?php
            $HeaderStyle = 'wpo-header-style-s11';
            ?>
            <?php include './partials/header-topbar-s2.php' ?>
            <?php include './partials/header-six.php' ?>
        </header>
        <!-- end of header -->

        <!-- start wpo-page-title -->
        <?php
        $Title = 'Home / Privacy Policy';
        ?>
        <?php include './partials/page-header.php' ?>
        <!-- end page-title -->

        <!-- start pf-terms-section -->
        <section class="pf-terms-section section-padding pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="pf-terms-wrap">
                            <div class="pf-terms-img">
                                <img src="assets/images/terms/terms.jpg" alt="">
                            </div>
                            <div class="pf-terms-text">
                                <h2>Reasons for Using Website Privacy Policy</h2>
                                <p>When you are planning to create a website, it’s very easy to overlook creating and
                                    adding a website Privacy Policy template. This is because when you are
                                    browsing through sites, you may not look at this part unless you really have to –
                                    and even then, you might not actually read all the content! However, it’s very
                                    important to have the terms page on your website, for a number of reasons. Once
                                    you’ve learned all about these reasons, you may realize that adding this part to
                                    your website is really essential.</p>
                                <p>Even a short Privacy Policy agreement should include several key clauses to
                                    safeguard your business. For example, if you’re selling online and incorrectly price
                                    an item, your Privacy Policy are what will enable you to cancel the order.</p>

                                <ul>
                                    <li>Acceptable use of your website and all of its content.</li>
                                    <li>Rules on uploading any content in your website.</li>
                                    <li>Any and all websites which are linked to your own.</li>
                                    <li>The availability of your website.</li>
                                    <li>Returns and Guarantees for Customers</li>
                                </ul>
                                <p>If any estimates of how long it will take the cleaning operatives to complete the job
                                    are being provided those are only estimates based on the average time it takes to
                                    clean a home or an office of similar size to the Client’s, it being difficult to
                                    calculate precisely how long such tasks may take and that a degree of flexibility
                                    may be required. Please note that one off cleans may take longer to complete due to
                                    longer intervals between cleaning sessions, number and type of cleaning tasks
                                    required, when compared to the regular maintenance cleaning of the same property.
                                </p>
                                <div class="row t-sub">
                                    <div class="col-md-6 col-sm-6 col-12">
                                        <div class="pf-p-details-img">
                                            <img src="assets/images/terms/1.jpg" alt="">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-12">
                                        <div class="pf-p-details-img">
                                            <img src="assets/images/terms/2.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <p>Post Construction Cleaning (Builders Cleaning), Event Cleaning or badly neglected
                                    homes may take up to three times longer than a well maintained home requiring
                                    general cleaning. Therefore the Company advises the Client to ask f or our
                                    specialist cleaning services: Builders Cleaning or Event Cleaning.</p>

                            </div>
                            <div class="pf-faq-section">
                                <h4>Frequently Ask Questions</h4>
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-12">
                                        <div class="accordion" id="accordionExample">
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingOne">
                                                    <button class="accordion-button" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                                        aria-expanded="true" aria-controls="collapseOne">
                                                        Modern Equipment We Use and support from our experts.
                                                    </button>
                                                </h3>
                                                <div id="collapseOne" class="accordion-collapse collapse show"
                                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eum
                                                            exercitationem pariatur iure nemo esse repellendus est quo
                                                            recusandae. Delectus, maxime.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingTwo">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                        aria-expanded="false" aria-controls="collapseTwo">
                                                        Planning can help alleviate workplace stress and increase
                                                        productivity.
                                                    </button>
                                                </h3>
                                                <div id="collapseTwo" class="accordion-collapse collapse"
                                                    aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eum
                                                            exercitationem pariatur iure nemo esse repellendus est quo
                                                            recusandae. Delectus, maxime.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingThree">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                        aria-expanded="false" aria-controls="collapseThree">
                                                        Those who experiment the most, are able to innovate the best.
                                                    </button>
                                                </h3>
                                                <div id="collapseThree" class="accordion-collapse collapse"
                                                    aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eum
                                                            exercitationem pariatur iure nemo esse repellendus est quo
                                                            recusandae. Delectus, maxime.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingFour">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                        aria-expanded="false" aria-controls="collapseFour">
                                                        Understand Your Problem, You must understand the issue.
                                                    </button>
                                                </h3>
                                                <div id="collapseFour" class="accordion-collapse collapse"
                                                    aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eum
                                                            exercitationem pariatur iure nemo esse repellendus est quo
                                                            recusandae. Delectus, maxime.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--  start wpo-contact-map -->
        <section class="wpo-contact-map-section">
            <h2 class="hidden">Contact map</h2>
            <div class="wpo-contact-map">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193595.9147703055!2d-74.11976314309273!3d40.69740344223377!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbd!4v1547528325671"
                    allowfullscreen></iframe>
            </div>
        </section>
        <!-- end wpo-contact-map -->


        <!-- start wpo-site-footer -->
        <?php include './partials/footer.php' ?>
        <!-- end wpo-site-footer -->

    </div>
    <!-- end of page-wrapper -->
    <?php include './partials/script.php' ?>
</body>

</html>
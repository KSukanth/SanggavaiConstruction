<!DOCTYPE html>
<html lang="en">
<?php include './partials/head.php' ?>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <?php include './partials/preloader.php' ?>
        <!-- end preloader -->

        <!--  cursor style -->
        <div class="cursor"></div>
        <div class="cursor2"></div>

        <!-- Start header -->
        <header id="header">
            <?php include './partials/header-topbar.php' ?>
            <?php include './partials/header-six.php' ?>
        </header>
        <!-- end of header -->

        <!-- start wpo-page-title -->
        <?php
        $Title = 'Our Blog / Blog Details';
        $MainTitle = 'From Concept to Reality: The Journey of Designing a Landmark';
        ?>
        <?php include './partials/page-header.php' ?>
        <!-- end page-title -->

        <!--===== start wpo-blog-section =====-->
        <section class="wpo-blog-single-section wpo-blog-single-left-sidebar-section section-padding pt-0">
            <div class="container-fluid">
                <div class="wpo-blog-wraper">
                    <div class="wpo-blog-content">
                        <div class="post format-standard-image scroll-text-animation" data-animation="fade_from_bottom">
                            <div class="entry-media">
                                <img src="assets/images/blog-details/1.jpg" alt>
                            </div>
                            <div class="entry-meta">
                                <ul>
                                    <li>By:<a href="#">admin </a> </li>
                                    <li>Date: Sep 09, 2025</li>
                                </ul>
                            </div>

                            <p><span>A</span>rchitecture dolor sit amet consectetur. Dignissim id sagittis vitae auctor.
                                Interdum
                                quam faucibus nisl enim quis. Et mattis nisl at sagittis urna vitae nec vel risus. Nisl
                                eget dictumst tincidunt elementum aliquet. Congue at cras nam habitant ac. Ac vehicula
                                tempus ante massa dictum nibh non. Ultrices urna dui dolor metus porta tellus enim odio.
                                Maecenas diam nisl mattis tincidunt consequat hac. Sed sit ipsum porta dapibus facilisis
                                et faucibus. Mauris mauris in massa consectetur. Felis cursus aliquam placerat ipsum
                                mauris consequat. Volutpat ultricies faucibus donec pellentesque eu dignissim enim.
                                <br><br>
                                Senectus faucibus arcu pulvinar libero. At consequat sed mattis neque a volutpat ut nisl
                                nisi. Ut sit sed leo dolor in sodales. In mus nisi facilisi augue nulla maecenas. Amet a
                                sodales interdum amet purus. Accumsan cursus pulvinar neque ullamcorper dui id urna. Id
                                nisl vitae turpis varius.
                            </p>
                            <blockquote>
                                The Role of Functionality in Contemporary Architecture Small Spaces, Big Ideas:
                                Innovative Solutions for Compact Living
                                <h4>-Cameron Williamson, <span>Senior Interior Designer</span></h4>
                            </blockquote>
                            <h2>Targeted Goal For Perfect Building</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown
                                printer took a galley of type and scrambled it to make a type specimen book.</p>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown
                                printer took a galley of type and scrambled it to make a type specimen book.</p>

                            <div class="gallery scroll-text-animation" data-animation="fade_from_bottom">
                                <div>
                                    <img src="assets/images/blog-details/img-1.jpg" alt="">
                                </div>
                                <div>
                                    <img src="assets/images/blog-details/img-2.jpg" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="tag-wrap scroll-text-animation" data-animation="fade_from_bottom">
                            <div class="tag-share-s2">
                                <div class="tag">
                                    <span>Share Article: </span>
                                    <ul>
                                        <li><a href="#"><i class="ti-facebook"></i></a></li>
                                        <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                        <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                        <li><a href="#"><i class="ti-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- end tag-share -->
                            <div class="tag-share">
                                <div class="tag">
                                    <span>Tags:</span>
                                    <ul>
                                        <li><a href="#">Architecture</a></li>
                                        <li><a href="#">Interior</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- end tag-share -->
                        </div>

                        <div class="more-posts scroll-text-animation" data-animation="fade_from_bottom">
                            <div class="previous-post">
                                <a href="blog.php">
                                    <span class="post-control-link">Previous Post</span>
                                    <span class="post-name">Reviving the Past: A Deep Dive into Historic Building
                                        Restoration</span>
                                </a>
                            </div>
                            <div class="next-post">
                                <a href="blog-left-sidebar.php">
                                    <span class="post-control-link">Next Post</span>
                                    <span class="post-name">10 Iconic Buildings That Redefined Modern
                                        Architecture</span>
                                </a>
                            </div>
                        </div>

                        <div class="comments-area scroll-text-animation" data-animation="fade_from_bottom">
                            <div class="comments-section">
                                <h3 class="comments-title">Comments:</h3>
                                <ol class="comments">
                                    <li class="comment even thread-even depth-1" id="comment-1">
                                        <div id="div-comment-1">
                                            <div class="comment-theme">
                                                <div class="comment-image"><img
                                                        src="assets/images/blog-details/comments-author/img-1.jpg" alt>
                                                </div>
                                            </div>
                                            <div class="comment-main-area">
                                                <div class="comment-wrapper">
                                                    <div class="comments-meta">
                                                        <h4>Kristin Watson</h4>
                                                        <span class="comments-date">Founder Of Megan</span>
                                                    </div>
                                                    <div class="comment-area">
                                                        <p>Turpis nulla proin donec a ridiculus. Mi suspendisse faucibus
                                                            sed lacus. Vitae risus eu nullam sed quam. Eget aenean id
                                                            augue pellentesque turpis magna egestas arcu sed. Turpis
                                                            integer aliquam aliquam aliquam.
                                                            <a class="comment-reply-link"
                                                                href="#">Reply...</a>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <ul class="children">
                                            <li class="comment">
                                                <div>
                                                    <div class="comment-theme">
                                                        <div class="comment-image"><img
                                                                src="assets/images/blog-details/comments-author/img-2.jpg"
                                                                alt></div>
                                                    </div>
                                                    <div class="comment-main-area">
                                                        <div class="comment-wrapper">
                                                            <div class="comments-meta">
                                                                <h4>Cody Fisher</h4>
                                                                <span class="comments-date">Interior Designer</span>
                                                            </div>
                                                            <div class="comment-area">
                                                                <p>Vitae risus eu nullam sed quam. Eget aenean id augue
                                                                    pellentesque turpis magna egestas arcu sed. Turpis
                                                                    integer aliquam aliquam aliquam.

                                                                    <a class="comment-reply-link"
                                                                        href="#">Reply...</a>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <span class="shape">
                                                <svg width="107" height="261" viewBox="0 0 107 261" fill="none">
                                                    <path d="M1 0V240C1 251.046 9.9543 260 21 260H107"
                                                        stroke="#D9D9D9" />
                                                </svg>
                                            </span>
                                        </ul>
                                    </li>
                                    <li class="comment">
                                        <div>
                                            <div class="comment-theme">
                                                <div class="comment-image"><img
                                                        src="assets/images/blog-details/comments-author/img-3.jpg" alt>
                                                </div>
                                            </div>
                                            <div class="comment-main-area">
                                                <div class="comment-wrapper">
                                                    <div class="comments-meta">
                                                        <h4>Kristin Watson</h4>
                                                        <span class="comments-date">Founder Of Megan</span>
                                                    </div>
                                                    <div class="comment-area">
                                                        <p>Turpis nulla proin donec a ridiculus. Mi suspendisse faucibus
                                                            sed lacus. Vitae risus eu nullam sed quam. Eget aenean id
                                                            augue pellentesque turpis magna egestas arcu sed. Turpis
                                                            integer aliquam aliquam aliquam.
                                                            <a class="comment-reply-link" href="#">Reply...</a>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ol>
                            </div>

                            <div class="comment-respond scroll-text-animation" data-animation="fade_from_bottom">
                                <h3 class="comment-reply-title">Leave a comment:</h3>
                                <form class="comment-form">
                                    <div class="form-inputs">
                                        <input placeholder="Name:" type="text">
                                        <input placeholder="Email:" type="email">
                                    </div>
                                    <div class="form-textarea">
                                        <textarea id="comment" placeholder="Message here..."></textarea>
                                    </div>
                                    <div class="form-submit">
                                        <input id="submit" value="GET A QUOTE" type="submit">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- start blog-sidebar -->
                    <?php include './partials/blog-sidebar.php' ?>
                </div>
            </div>
        </section>


        <!-- start wpo-site-footer -->
        <?php include './partials/footer.php' ?>
        <!-- end wpo-site-footer -->

    </div>
    <!-- end of page-wrapper -->
    <?php include './partials/script.php' ?>
</body>

</html>